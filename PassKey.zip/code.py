from password.npass import Npass

if __name__ == "__main__":
    npass = Npass()
    npass.start()
